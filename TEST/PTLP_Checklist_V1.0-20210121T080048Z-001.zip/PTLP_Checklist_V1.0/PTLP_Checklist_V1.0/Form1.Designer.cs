﻿namespace PTLP_Checklist_V1._0
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.SerialPort_comboBox = new System.Windows.Forms.ComboBox();
            this.Step_1 = new System.Windows.Forms.Label();
            this.Logo = new System.Windows.Forms.PictureBox();
            this.Member_of_Sintek_Group = new System.Windows.Forms.Label();
            this.Project_Name = new System.Windows.Forms.Label();
            this.Company_name = new System.Windows.Forms.Label();
            this.Project_number_label = new System.Windows.Forms.Label();
            this.Project_number_textBox = new System.Windows.Forms.TextBox();
            this.Master_SN_label = new System.Windows.Forms.Label();
            this.Master_SN_textBox = new System.Windows.Forms.TextBox();
            this.Port2_checkBox = new System.Windows.Forms.CheckBox();
            this.Port3_checkBox = new System.Windows.Forms.CheckBox();
            this.Port4_checkBox = new System.Windows.Forms.CheckBox();
            this.Port5_checkBox = new System.Windows.Forms.CheckBox();
            this.Port2_SN_textBox = new System.Windows.Forms.TextBox();
            this.Port3_SN_textBox = new System.Windows.Forms.TextBox();
            this.Port4_SN_textBox = new System.Windows.Forms.TextBox();
            this.Port5_SN_textBox = new System.Windows.Forms.TextBox();
            this.Project_number_Save_button = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.Visual_inspection = new System.Windows.Forms.TabPage();
            this.Q8_O2_SN_textBox = new System.Windows.Forms.TextBox();
            this.Q7_O2_SN_textBox = new System.Windows.Forms.TextBox();
            this.Q8_O2_V_textBox = new System.Windows.Forms.TextBox();
            this.Q7_O2_V_textBox = new System.Windows.Forms.TextBox();
            this.Power_cord_length_textBox = new System.Windows.Forms.TextBox();
            this.Q6_Yes_CheckBox = new System.Windows.Forms.CheckBox();
            this.Q6_NO_CheckBox = new System.Windows.Forms.CheckBox();
            this.Fuse_textBox = new System.Windows.Forms.TextBox();
            this.NFB_textBox = new System.Windows.Forms.TextBox();
            this.Q1_2_label = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Q1_1_label = new System.Windows.Forms.Label();
            this.Q1_3_label = new System.Windows.Forms.Label();
            this.Q7_label = new System.Windows.Forms.Label();
            this.Q6_label = new System.Windows.Forms.Label();
            this.Q5_label = new System.Windows.Forms.Label();
            this.Q8_label = new System.Windows.Forms.Label();
            this.Q4_label = new System.Windows.Forms.Label();
            this.Q3_label = new System.Windows.Forms.Label();
            this.Q2_label = new System.Windows.Forms.Label();
            this.Q1_label = new System.Windows.Forms.Label();
            this.Power_safety_inspection = new System.Windows.Forms.TabPage();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.Power_transmission_inspection = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.Machine_number_label = new System.Windows.Forms.Label();
            this.Machine_number_textBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.MAC_TO_HOST_textBox = new System.Windows.Forms.TextBox();
            this.MAC_TO_PLCtextBox = new System.Windows.Forms.TextBox();
            this.GET_MAC_button = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.Logo)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.Visual_inspection.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.Power_safety_inspection.SuspendLayout();
            this.Power_transmission_inspection.SuspendLayout();
            this.SuspendLayout();
            // 
            // SerialPort_comboBox
            // 
            this.SerialPort_comboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.SerialPort_comboBox.FormattingEnabled = true;
            this.SerialPort_comboBox.Location = new System.Drawing.Point(235, 13);
            this.SerialPort_comboBox.Name = "SerialPort_comboBox";
            this.SerialPort_comboBox.Size = new System.Drawing.Size(220, 20);
            this.SerialPort_comboBox.TabIndex = 100;
            this.SerialPort_comboBox.DropDown += new System.EventHandler(this.SerialPort_comboBox_DropDown);
            this.SerialPort_comboBox.SelectedIndexChanged += new System.EventHandler(this.SerialPort_comboBox_SelectedIndexChanged);
            this.SerialPort_comboBox.Enter += new System.EventHandler(this.GetFocusIndex);
            // 
            // Step_1
            // 
            this.Step_1.AutoSize = true;
            this.Step_1.Font = new System.Drawing.Font("宋体", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Step_1.Location = new System.Drawing.Point(12, 9);
            this.Step_1.Name = "Step_1";
            this.Step_1.Size = new System.Drawing.Size(217, 29);
            this.Step_1.TabIndex = 4;
            this.Step_1.Text = "選擇 COM Port";
            // 
            // Logo
            // 
            this.Logo.Image = ((System.Drawing.Image)(resources.GetObject("Logo.Image")));
            this.Logo.Location = new System.Drawing.Point(18, 49);
            this.Logo.Name = "Logo";
            this.Logo.Size = new System.Drawing.Size(166, 57);
            this.Logo.TabIndex = 5;
            this.Logo.TabStop = false;
            // 
            // Member_of_Sintek_Group
            // 
            this.Member_of_Sintek_Group.AutoSize = true;
            this.Member_of_Sintek_Group.Font = new System.Drawing.Font("Arial", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Member_of_Sintek_Group.Location = new System.Drawing.Point(20, 109);
            this.Member_of_Sintek_Group.Name = "Member_of_Sintek_Group";
            this.Member_of_Sintek_Group.Size = new System.Drawing.Size(163, 16);
            this.Member_of_Sintek_Group.TabIndex = 6;
            this.Member_of_Sintek_Group.Text = "Member of Sintek Group";
            // 
            // Project_Name
            // 
            this.Project_Name.AutoSize = true;
            this.Project_Name.Font = new System.Drawing.Font("Arial", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Project_Name.Location = new System.Drawing.Point(392, 98);
            this.Project_Name.Name = "Project_Name";
            this.Project_Name.Size = new System.Drawing.Size(247, 27);
            this.Project_Name.TabIndex = 8;
            this.Project_Name.Text = "TLP電控盤自主檢驗表";
            // 
            // Company_name
            // 
            this.Company_name.AutoSize = true;
            this.Company_name.Font = new System.Drawing.Font("楷体", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Company_name.Location = new System.Drawing.Point(343, 49);
            this.Company_name.Name = "Company_name";
            this.Company_name.Size = new System.Drawing.Size(345, 33);
            this.Company_name.TabIndex = 9;
            this.Company_name.Text = "靄崴科技股份有限公司";
            // 
            // Project_number_label
            // 
            this.Project_number_label.AutoSize = true;
            this.Project_number_label.Font = new System.Drawing.Font("楷体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Project_number_label.Location = new System.Drawing.Point(14, 142);
            this.Project_number_label.Name = "Project_number_label";
            this.Project_number_label.Size = new System.Drawing.Size(109, 19);
            this.Project_number_label.TabIndex = 10;
            this.Project_number_label.Text = "專案工號：";
            // 
            // Project_number_textBox
            // 
            this.Project_number_textBox.Font = new System.Drawing.Font("楷体", 14.25F);
            this.Project_number_textBox.Location = new System.Drawing.Point(110, 137);
            this.Project_number_textBox.Name = "Project_number_textBox";
            this.Project_number_textBox.Size = new System.Drawing.Size(139, 29);
            this.Project_number_textBox.TabIndex = 14;
            this.Project_number_textBox.Click += new System.EventHandler(this.Project_number_textBox_Click);
            this.Project_number_textBox.Enter += new System.EventHandler(this.GetFocusIndex);
            this.Project_number_textBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.keyDown_E);
            // 
            // Master_SN_label
            // 
            this.Master_SN_label.AutoSize = true;
            this.Master_SN_label.Font = new System.Drawing.Font("楷体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Master_SN_label.Location = new System.Drawing.Point(452, 142);
            this.Master_SN_label.Name = "Master_SN_label";
            this.Master_SN_label.Size = new System.Drawing.Size(189, 19);
            this.Master_SN_label.TabIndex = 12;
            this.Master_SN_label.Text = "主控盤出廠流水號：";
            // 
            // Master_SN_textBox
            // 
            this.Master_SN_textBox.Font = new System.Drawing.Font("楷体", 14.25F);
            this.Master_SN_textBox.Location = new System.Drawing.Point(628, 137);
            this.Master_SN_textBox.Name = "Master_SN_textBox";
            this.Master_SN_textBox.Size = new System.Drawing.Size(150, 29);
            this.Master_SN_textBox.TabIndex = 1;
            this.Master_SN_textBox.Click += new System.EventHandler(this.Master_SN_textBox_Click);
            this.Master_SN_textBox.Enter += new System.EventHandler(this.GetFocusIndex);
            this.Master_SN_textBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.keyDown_E);
            // 
            // Port2_checkBox
            // 
            this.Port2_checkBox.AutoSize = true;
            this.Port2_checkBox.Font = new System.Drawing.Font("楷体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Port2_checkBox.Location = new System.Drawing.Point(403, 172);
            this.Port2_checkBox.Name = "Port2_checkBox";
            this.Port2_checkBox.Size = new System.Drawing.Size(238, 23);
            this.Port2_checkBox.TabIndex = 14;
            this.Port2_checkBox.Text = "擴充盤流水號_port 2：";
            this.Port2_checkBox.UseVisualStyleBackColor = true;
            this.Port2_checkBox.CheckedChanged += new System.EventHandler(this.Port2_checkBox_CheckedChanged);
            // 
            // Port3_checkBox
            // 
            this.Port3_checkBox.AutoSize = true;
            this.Port3_checkBox.Font = new System.Drawing.Font("楷体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Port3_checkBox.Location = new System.Drawing.Point(403, 204);
            this.Port3_checkBox.Name = "Port3_checkBox";
            this.Port3_checkBox.Size = new System.Drawing.Size(238, 23);
            this.Port3_checkBox.TabIndex = 15;
            this.Port3_checkBox.Text = "擴充盤流水號_port 3：";
            this.Port3_checkBox.UseVisualStyleBackColor = true;
            this.Port3_checkBox.CheckedChanged += new System.EventHandler(this.Port3_checkBox_CheckedChanged);
            // 
            // Port4_checkBox
            // 
            this.Port4_checkBox.AutoSize = true;
            this.Port4_checkBox.Font = new System.Drawing.Font("楷体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Port4_checkBox.Location = new System.Drawing.Point(403, 236);
            this.Port4_checkBox.Name = "Port4_checkBox";
            this.Port4_checkBox.Size = new System.Drawing.Size(238, 23);
            this.Port4_checkBox.TabIndex = 16;
            this.Port4_checkBox.Text = "擴充盤流水號_port 4：";
            this.Port4_checkBox.UseVisualStyleBackColor = true;
            this.Port4_checkBox.CheckedChanged += new System.EventHandler(this.Port4_checkBox_CheckedChanged);
            // 
            // Port5_checkBox
            // 
            this.Port5_checkBox.AutoSize = true;
            this.Port5_checkBox.Font = new System.Drawing.Font("楷体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Port5_checkBox.Location = new System.Drawing.Point(403, 268);
            this.Port5_checkBox.Name = "Port5_checkBox";
            this.Port5_checkBox.Size = new System.Drawing.Size(238, 23);
            this.Port5_checkBox.TabIndex = 17;
            this.Port5_checkBox.Text = "擴充盤流水號_port 5：";
            this.Port5_checkBox.UseVisualStyleBackColor = true;
            this.Port5_checkBox.CheckedChanged += new System.EventHandler(this.Port5_checkBox_CheckedChanged);
            // 
            // Port2_SN_textBox
            // 
            this.Port2_SN_textBox.Font = new System.Drawing.Font("楷体", 14.25F);
            this.Port2_SN_textBox.Location = new System.Drawing.Point(628, 169);
            this.Port2_SN_textBox.Name = "Port2_SN_textBox";
            this.Port2_SN_textBox.Size = new System.Drawing.Size(150, 29);
            this.Port2_SN_textBox.TabIndex = 2;
            this.Port2_SN_textBox.Click += new System.EventHandler(this.Port2_SN_textBox_Click);
            this.Port2_SN_textBox.Enter += new System.EventHandler(this.GetFocusIndex);
            this.Port2_SN_textBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.keyDown_E);
            // 
            // Port3_SN_textBox
            // 
            this.Port3_SN_textBox.Font = new System.Drawing.Font("楷体", 14.25F);
            this.Port3_SN_textBox.Location = new System.Drawing.Point(628, 201);
            this.Port3_SN_textBox.Name = "Port3_SN_textBox";
            this.Port3_SN_textBox.Size = new System.Drawing.Size(150, 29);
            this.Port3_SN_textBox.TabIndex = 3;
            this.Port3_SN_textBox.Click += new System.EventHandler(this.Port3_SN_textBox_Click);
            this.Port3_SN_textBox.Enter += new System.EventHandler(this.GetFocusIndex);
            this.Port3_SN_textBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.keyDown_E);
            // 
            // Port4_SN_textBox
            // 
            this.Port4_SN_textBox.Font = new System.Drawing.Font("楷体", 14.25F);
            this.Port4_SN_textBox.Location = new System.Drawing.Point(628, 233);
            this.Port4_SN_textBox.Name = "Port4_SN_textBox";
            this.Port4_SN_textBox.Size = new System.Drawing.Size(150, 29);
            this.Port4_SN_textBox.TabIndex = 4;
            this.Port4_SN_textBox.Click += new System.EventHandler(this.Port4_SN_textBox_Click);
            this.Port4_SN_textBox.Enter += new System.EventHandler(this.GetFocusIndex);
            this.Port4_SN_textBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.keyDown_E);
            // 
            // Port5_SN_textBox
            // 
            this.Port5_SN_textBox.Font = new System.Drawing.Font("楷体", 14.25F);
            this.Port5_SN_textBox.Location = new System.Drawing.Point(628, 265);
            this.Port5_SN_textBox.Name = "Port5_SN_textBox";
            this.Port5_SN_textBox.Size = new System.Drawing.Size(150, 29);
            this.Port5_SN_textBox.TabIndex = 5;
            this.Port5_SN_textBox.Click += new System.EventHandler(this.Port5_SN_textBox_Click);
            this.Port5_SN_textBox.Enter += new System.EventHandler(this.GetFocusIndex);
            this.Port5_SN_textBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.keyDown_E);
            // 
            // Project_number_Save_button
            // 
            this.Project_number_Save_button.Font = new System.Drawing.Font("楷体", 14.25F);
            this.Project_number_Save_button.Location = new System.Drawing.Point(253, 136);
            this.Project_number_Save_button.Name = "Project_number_Save_button";
            this.Project_number_Save_button.Size = new System.Drawing.Size(83, 30);
            this.Project_number_Save_button.TabIndex = 22;
            this.Project_number_Save_button.Text = "Save";
            this.Project_number_Save_button.UseVisualStyleBackColor = true;
            this.Project_number_Save_button.Click += new System.EventHandler(this.Project_number_Save);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.Visual_inspection);
            this.tabControl1.Controls.Add(this.Power_safety_inspection);
            this.tabControl1.Controls.Add(this.Power_transmission_inspection);
            this.tabControl1.Font = new System.Drawing.Font("楷体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tabControl1.Location = new System.Drawing.Point(25, 345);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(751, 383);
            this.tabControl1.TabIndex = 23;
            // 
            // Visual_inspection
            // 
            this.Visual_inspection.Controls.Add(this.Q8_O2_SN_textBox);
            this.Visual_inspection.Controls.Add(this.Q7_O2_SN_textBox);
            this.Visual_inspection.Controls.Add(this.Q8_O2_V_textBox);
            this.Visual_inspection.Controls.Add(this.Q7_O2_V_textBox);
            this.Visual_inspection.Controls.Add(this.Power_cord_length_textBox);
            this.Visual_inspection.Controls.Add(this.Q6_Yes_CheckBox);
            this.Visual_inspection.Controls.Add(this.Q6_NO_CheckBox);
            this.Visual_inspection.Controls.Add(this.Fuse_textBox);
            this.Visual_inspection.Controls.Add(this.NFB_textBox);
            this.Visual_inspection.Controls.Add(this.Q1_2_label);
            this.Visual_inspection.Controls.Add(this.pictureBox1);
            this.Visual_inspection.Controls.Add(this.Q1_1_label);
            this.Visual_inspection.Controls.Add(this.Q1_3_label);
            this.Visual_inspection.Controls.Add(this.Q7_label);
            this.Visual_inspection.Controls.Add(this.Q6_label);
            this.Visual_inspection.Controls.Add(this.Q5_label);
            this.Visual_inspection.Controls.Add(this.Q8_label);
            this.Visual_inspection.Controls.Add(this.Q4_label);
            this.Visual_inspection.Controls.Add(this.Q3_label);
            this.Visual_inspection.Controls.Add(this.Q2_label);
            this.Visual_inspection.Controls.Add(this.Q1_label);
            this.Visual_inspection.Location = new System.Drawing.Point(4, 26);
            this.Visual_inspection.Name = "Visual_inspection";
            this.Visual_inspection.Padding = new System.Windows.Forms.Padding(3);
            this.Visual_inspection.Size = new System.Drawing.Size(743, 353);
            this.Visual_inspection.TabIndex = 0;
            this.Visual_inspection.Text = "元件目視檢查";
            this.Visual_inspection.UseVisualStyleBackColor = true;
            // 
            // Q8_O2_SN_textBox
            // 
            this.Q8_O2_SN_textBox.Location = new System.Drawing.Point(401, 319);
            this.Q8_O2_SN_textBox.Name = "Q8_O2_SN_textBox";
            this.Q8_O2_SN_textBox.Size = new System.Drawing.Size(146, 26);
            this.Q8_O2_SN_textBox.TabIndex = 12;
            this.Q8_O2_SN_textBox.Click += new System.EventHandler(this.Q8_O2_Click);
            this.Q8_O2_SN_textBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.keyDown_E);
            // 
            // Q7_O2_SN_textBox
            // 
            this.Q7_O2_SN_textBox.Location = new System.Drawing.Point(401, 290);
            this.Q7_O2_SN_textBox.Name = "Q7_O2_SN_textBox";
            this.Q7_O2_SN_textBox.Size = new System.Drawing.Size(146, 26);
            this.Q7_O2_SN_textBox.TabIndex = 10;
            this.Q7_O2_SN_textBox.Click += new System.EventHandler(this.Q7_O2_Click);
            this.Q7_O2_SN_textBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.keyDown_E);
            // 
            // Q8_O2_V_textBox
            // 
            this.Q8_O2_V_textBox.Location = new System.Drawing.Point(229, 319);
            this.Q8_O2_V_textBox.Name = "Q8_O2_V_textBox";
            this.Q8_O2_V_textBox.Size = new System.Drawing.Size(68, 26);
            this.Q8_O2_V_textBox.TabIndex = 11;
            this.Q8_O2_V_textBox.Click += new System.EventHandler(this.Q8_O2_Click);
            this.Q8_O2_V_textBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.keyDown_E);
            // 
            // Q7_O2_V_textBox
            // 
            this.Q7_O2_V_textBox.Location = new System.Drawing.Point(229, 290);
            this.Q7_O2_V_textBox.Name = "Q7_O2_V_textBox";
            this.Q7_O2_V_textBox.Size = new System.Drawing.Size(68, 26);
            this.Q7_O2_V_textBox.TabIndex = 9;
            this.Q7_O2_V_textBox.Click += new System.EventHandler(this.Q7_O2_Click);
            this.Q7_O2_V_textBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.keyDown_E);
            // 
            // Power_cord_length_textBox
            // 
            this.Power_cord_length_textBox.Location = new System.Drawing.Point(417, 260);
            this.Power_cord_length_textBox.Name = "Power_cord_length_textBox";
            this.Power_cord_length_textBox.Size = new System.Drawing.Size(116, 26);
            this.Power_cord_length_textBox.TabIndex = 8;
            this.Power_cord_length_textBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.keyDown_E);
            // 
            // Q6_Yes_CheckBox
            // 
            this.Q6_Yes_CheckBox.AutoSize = true;
            this.Q6_Yes_CheckBox.Font = new System.Drawing.Font("楷体", 14F, System.Drawing.FontStyle.Bold);
            this.Q6_Yes_CheckBox.Location = new System.Drawing.Point(313, 263);
            this.Q6_Yes_CheckBox.Name = "Q6_Yes_CheckBox";
            this.Q6_Yes_CheckBox.Size = new System.Drawing.Size(265, 23);
            this.Q6_Yes_CheckBox.TabIndex = 34;
            this.Q6_Yes_CheckBox.Text = "有：線長           M。";
            this.Q6_Yes_CheckBox.UseVisualStyleBackColor = true;
            this.Q6_Yes_CheckBox.CheckedChanged += new System.EventHandler(this.Q6_Yes_CheckBox_CheckedChanged);
            // 
            // Q6_NO_CheckBox
            // 
            this.Q6_NO_CheckBox.AutoSize = true;
            this.Q6_NO_CheckBox.Font = new System.Drawing.Font("楷体", 14F, System.Drawing.FontStyle.Bold);
            this.Q6_NO_CheckBox.Location = new System.Drawing.Point(254, 263);
            this.Q6_NO_CheckBox.Name = "Q6_NO_CheckBox";
            this.Q6_NO_CheckBox.Size = new System.Drawing.Size(49, 23);
            this.Q6_NO_CheckBox.TabIndex = 33;
            this.Q6_NO_CheckBox.Text = "無";
            this.Q6_NO_CheckBox.UseVisualStyleBackColor = true;
            this.Q6_NO_CheckBox.CheckedChanged += new System.EventHandler(this.Q6_NO_CheckBox_CheckedChanged);
            // 
            // Fuse_textBox
            // 
            this.Fuse_textBox.Location = new System.Drawing.Point(182, 67);
            this.Fuse_textBox.Name = "Fuse_textBox";
            this.Fuse_textBox.Size = new System.Drawing.Size(157, 26);
            this.Fuse_textBox.TabIndex = 7;
            this.Fuse_textBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.keyDown_E);
            // 
            // NFB_textBox
            // 
            this.NFB_textBox.Location = new System.Drawing.Point(225, 37);
            this.NFB_textBox.Name = "NFB_textBox";
            this.NFB_textBox.Size = new System.Drawing.Size(123, 26);
            this.NFB_textBox.TabIndex = 6;
            this.NFB_textBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.keyDown_E);
            // 
            // Q1_2_label
            // 
            this.Q1_2_label.AutoSize = true;
            this.Q1_2_label.Font = new System.Drawing.Font("楷体", 15F, System.Drawing.FontStyle.Bold);
            this.Q1_2_label.Location = new System.Drawing.Point(7, 70);
            this.Q1_2_label.Name = "Q1_2_label";
            this.Q1_2_label.Size = new System.Drawing.Size(389, 20);
            this.Q1_2_label.TabIndex = 30;
            this.Q1_2_label.Text = "   2.保險絲F1為                A 。";
            this.Q1_2_label.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(431, 10);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(163, 110);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // Q1_1_label
            // 
            this.Q1_1_label.AutoSize = true;
            this.Q1_1_label.Font = new System.Drawing.Font("楷体", 15F, System.Drawing.FontStyle.Bold);
            this.Q1_1_label.Location = new System.Drawing.Point(7, 40);
            this.Q1_1_label.Name = "Q1_1_label";
            this.Q1_1_label.Size = new System.Drawing.Size(398, 20);
            this.Q1_1_label.TabIndex = 29;
            this.Q1_1_label.Text = "   1.無熔絲開關Q1為             A 。";
            this.Q1_1_label.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Q1_3_label
            // 
            this.Q1_3_label.AutoSize = true;
            this.Q1_3_label.Font = new System.Drawing.Font("楷体", 15F, System.Drawing.FontStyle.Bold);
            this.Q1_3_label.Location = new System.Drawing.Point(7, 100);
            this.Q1_3_label.Name = "Q1_3_label";
            this.Q1_3_label.Size = new System.Drawing.Size(425, 20);
            this.Q1_3_label.TabIndex = 28;
            this.Q1_3_label.Text = "   3.檢查PLC模式切換是否為REM(如圖一)。";
            this.Q1_3_label.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Q7_label
            // 
            this.Q7_label.AutoSize = true;
            this.Q7_label.Font = new System.Drawing.Font("楷体", 14F, System.Drawing.FontStyle.Bold);
            this.Q7_label.Location = new System.Drawing.Point(7, 294);
            this.Q7_label.Name = "Q7_label";
            this.Q7_label.Size = new System.Drawing.Size(568, 19);
            this.Q7_label.TabIndex = 27;
            this.Q7_label.Text = "07:確認O2-1韌體版次：      、流水號：             。\r\n";
            this.Q7_label.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Q6_label
            // 
            this.Q6_label.AutoSize = true;
            this.Q6_label.Font = new System.Drawing.Font("楷体", 14F, System.Drawing.FontStyle.Bold);
            this.Q6_label.Location = new System.Drawing.Point(7, 265);
            this.Q6_label.Name = "Q6_label";
            this.Q6_label.Size = new System.Drawing.Size(231, 19);
            this.Q6_label.TabIndex = 27;
            this.Q6_label.Text = "06:確認有無附上電源線";
            this.Q6_label.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Q5_label
            // 
            this.Q5_label.AutoSize = true;
            this.Q5_label.Font = new System.Drawing.Font("楷体", 14F, System.Drawing.FontStyle.Bold);
            this.Q5_label.Location = new System.Drawing.Point(7, 236);
            this.Q5_label.Name = "Q5_label";
            this.Q5_label.Size = new System.Drawing.Size(441, 19);
            this.Q5_label.TabIndex = 27;
            this.Q5_label.Text = "05:確定各元件名稱及接地符號有無標示清楚。";
            this.Q5_label.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Q8_label
            // 
            this.Q8_label.AutoSize = true;
            this.Q8_label.Font = new System.Drawing.Font("楷体", 14F, System.Drawing.FontStyle.Bold);
            this.Q8_label.Location = new System.Drawing.Point(7, 323);
            this.Q8_label.Name = "Q8_label";
            this.Q8_label.Size = new System.Drawing.Size(568, 19);
            this.Q8_label.TabIndex = 0;
            this.Q8_label.Text = "08:確認O2-2韌體版次：      、流水號：             。\r\n";
            this.Q8_label.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Q4_label
            // 
            this.Q4_label.AutoSize = true;
            this.Q4_label.Font = new System.Drawing.Font("楷体", 14F, System.Drawing.FontStyle.Bold);
            this.Q4_label.Location = new System.Drawing.Point(7, 207);
            this.Q4_label.Name = "Q4_label";
            this.Q4_label.Size = new System.Drawing.Size(630, 19);
            this.Q4_label.TabIndex = 27;
            this.Q4_label.Text = "04:確定配電盤鈑金固定孔上的線槽有無擋到，盤內是否清潔乾淨。";
            this.Q4_label.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Q3_label
            // 
            this.Q3_label.AutoSize = true;
            this.Q3_label.Font = new System.Drawing.Font("楷体", 14F, System.Drawing.FontStyle.Bold);
            this.Q3_label.Location = new System.Drawing.Point(7, 159);
            this.Q3_label.Name = "Q3_label";
            this.Q3_label.Size = new System.Drawing.Size(399, 38);
            this.Q3_label.TabIndex = 7;
            this.Q3_label.Text = "03:確定各電源相序之間及接地沒有短路，\r\n   各接點螺絲鎖緊，號碼圈方向正確。";
            this.Q3_label.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Q2_label
            // 
            this.Q2_label.AutoSize = true;
            this.Q2_label.Font = new System.Drawing.Font("楷体", 14F, System.Drawing.FontStyle.Bold);
            this.Q2_label.Location = new System.Drawing.Point(7, 126);
            this.Q2_label.Name = "Q2_label";
            this.Q2_label.Size = new System.Drawing.Size(462, 19);
            this.Q2_label.TabIndex = 6;
            this.Q2_label.Text = "02:確定配電盤配線顏色、線徑和接線是否正確。";
            this.Q2_label.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Q1_label
            // 
            this.Q1_label.AutoSize = true;
            this.Q1_label.Font = new System.Drawing.Font("楷体", 15F, System.Drawing.FontStyle.Bold);
            this.Q1_label.Location = new System.Drawing.Point(7, 10);
            this.Q1_label.Name = "Q1_label";
            this.Q1_label.Size = new System.Drawing.Size(420, 20);
            this.Q1_label.TabIndex = 5;
            this.Q1_label.Text = "01:檢查所有元件規格及配置方向是否正確：";
            this.Q1_label.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Power_safety_inspection
            // 
            this.Power_safety_inspection.Controls.Add(this.textBox5);
            this.Power_safety_inspection.Controls.Add(this.textBox4);
            this.Power_safety_inspection.Controls.Add(this.textBox3);
            this.Power_safety_inspection.Controls.Add(this.textBox2);
            this.Power_safety_inspection.Controls.Add(this.textBox1);
            this.Power_safety_inspection.Controls.Add(this.label9);
            this.Power_safety_inspection.Controls.Add(this.label8);
            this.Power_safety_inspection.Controls.Add(this.label7);
            this.Power_safety_inspection.Controls.Add(this.label6);
            this.Power_safety_inspection.Controls.Add(this.label5);
            this.Power_safety_inspection.Controls.Add(this.label4);
            this.Power_safety_inspection.Location = new System.Drawing.Point(4, 26);
            this.Power_safety_inspection.Name = "Power_safety_inspection";
            this.Power_safety_inspection.Padding = new System.Windows.Forms.Padding(3);
            this.Power_safety_inspection.Size = new System.Drawing.Size(743, 353);
            this.Power_safety_inspection.TabIndex = 1;
            this.Power_safety_inspection.Text = "電源安全檢查";
            this.Power_safety_inspection.UseVisualStyleBackColor = true;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("楷体", 15F, System.Drawing.FontStyle.Bold);
            this.label9.Location = new System.Drawing.Point(6, 211);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(290, 20);
            this.label9.TabIndex = 11;
            this.label9.Text = "   PE對底板：          mΩ";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("楷体", 15F, System.Drawing.FontStyle.Bold);
            this.label8.Location = new System.Drawing.Point(6, 163);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(519, 40);
            this.label8.TabIndex = 10;
            this.label8.Text = "11:以交流接地阻抗測試機(GR-001)進行接地電阻測試;\r\n   測試數據10A/3s 量測值<100mΩ合格。\r\n";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("楷体", 15F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(6, 135);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(542, 20);
            this.label7.TabIndex = 9;
            this.label7.Text = "   L相對PE：          mA    N相對PE：          mA";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("楷体", 15F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(6, 87);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(456, 40);
            this.label6.TabIndex = 8;
            this.label6.Text = "10:以耐壓絕緣測試機(EST-300)進行耐壓測試；\r\n   測試數據1500V/1min 量測值<10mA合格。\r\n";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("楷体", 15F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(6, 59);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(551, 20);
            this.label5.TabIndex = 7;
            this.label5.Text = "   L相對PE：          MΩ   N相對PE：          MΩ";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("楷体", 15F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(6, 11);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(498, 40);
            this.label4.TabIndex = 6;
            this.label4.Text = "09:以耐壓絕緣測試機(EST-300)進行絕緣電阻測試；\r\n   測試數據500V 量測值>100MΩ合格。\r\n";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Power_transmission_inspection
            // 
            this.Power_transmission_inspection.Controls.Add(this.label20);
            this.Power_transmission_inspection.Controls.Add(this.label19);
            this.Power_transmission_inspection.Controls.Add(this.label18);
            this.Power_transmission_inspection.Controls.Add(this.label17);
            this.Power_transmission_inspection.Controls.Add(this.label16);
            this.Power_transmission_inspection.Controls.Add(this.label15);
            this.Power_transmission_inspection.Controls.Add(this.label14);
            this.Power_transmission_inspection.Controls.Add(this.label13);
            this.Power_transmission_inspection.Location = new System.Drawing.Point(4, 26);
            this.Power_transmission_inspection.Name = "Power_transmission_inspection";
            this.Power_transmission_inspection.Size = new System.Drawing.Size(743, 353);
            this.Power_transmission_inspection.TabIndex = 2;
            this.Power_transmission_inspection.Text = "送電檢驗";
            this.Power_transmission_inspection.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(205, 309);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(371, 32);
            this.label1.TabIndex = 24;
            this.label1.Text = "檢          驗          項          目";
            // 
            // Machine_number_label
            // 
            this.Machine_number_label.AutoSize = true;
            this.Machine_number_label.Font = new System.Drawing.Font("楷体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Machine_number_label.Location = new System.Drawing.Point(14, 270);
            this.Machine_number_label.Name = "Machine_number_label";
            this.Machine_number_label.Size = new System.Drawing.Size(109, 19);
            this.Machine_number_label.TabIndex = 25;
            this.Machine_number_label.Text = "機台編號：";
            // 
            // Machine_number_textBox
            // 
            this.Machine_number_textBox.Font = new System.Drawing.Font("楷体", 14.25F);
            this.Machine_number_textBox.Location = new System.Drawing.Point(110, 265);
            this.Machine_number_textBox.Name = "Machine_number_textBox";
            this.Machine_number_textBox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Machine_number_textBox.Size = new System.Drawing.Size(226, 29);
            this.Machine_number_textBox.TabIndex = 15;
            this.Machine_number_textBox.Enter += new System.EventHandler(this.GetFocusIndex);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(747, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 27;
            this.label2.Text = "label2";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(625, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 29;
            this.label3.Text = "label3";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("楷体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label10.Location = new System.Drawing.Point(14, 174);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(89, 19);
            this.label10.TabIndex = 101;
            this.label10.Text = "工業電腦";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("楷体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label11.Location = new System.Drawing.Point(14, 206);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(129, 19);
            this.label11.TabIndex = 102;
            this.label11.Text = "MAC TO HOST:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("楷体", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label12.Location = new System.Drawing.Point(14, 238);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(139, 19);
            this.label12.TabIndex = 103;
            this.label12.Text = "MAC2 TO  PLC:";
            // 
            // MAC_TO_HOST_textBox
            // 
            this.MAC_TO_HOST_textBox.Font = new System.Drawing.Font("楷体", 14.25F);
            this.MAC_TO_HOST_textBox.Location = new System.Drawing.Point(155, 200);
            this.MAC_TO_HOST_textBox.Name = "MAC_TO_HOST_textBox";
            this.MAC_TO_HOST_textBox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.MAC_TO_HOST_textBox.Size = new System.Drawing.Size(181, 29);
            this.MAC_TO_HOST_textBox.TabIndex = 104;
            // 
            // MAC_TO_PLCtextBox
            // 
            this.MAC_TO_PLCtextBox.Font = new System.Drawing.Font("楷体", 14.25F);
            this.MAC_TO_PLCtextBox.Location = new System.Drawing.Point(155, 232);
            this.MAC_TO_PLCtextBox.Name = "MAC_TO_PLCtextBox";
            this.MAC_TO_PLCtextBox.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.MAC_TO_PLCtextBox.Size = new System.Drawing.Size(181, 29);
            this.MAC_TO_PLCtextBox.TabIndex = 105;
            // 
            // GET_MAC_button
            // 
            this.GET_MAC_button.Font = new System.Drawing.Font("楷体", 14.25F);
            this.GET_MAC_button.Location = new System.Drawing.Point(109, 168);
            this.GET_MAC_button.Name = "GET_MAC_button";
            this.GET_MAC_button.Size = new System.Drawing.Size(227, 30);
            this.GET_MAC_button.TabIndex = 106;
            this.GET_MAC_button.Text = "GET MAC";
            this.GET_MAC_button.UseVisualStyleBackColor = true;
            this.GET_MAC_button.Click += new System.EventHandler(this.GET_MAC_button_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(130, 56);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(115, 26);
            this.textBox1.TabIndex = 12;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(400, 56);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(115, 26);
            this.textBox2.TabIndex = 13;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(130, 132);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(115, 26);
            this.textBox3.TabIndex = 14;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(400, 132);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(115, 26);
            this.textBox4.TabIndex = 15;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(139, 208);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(115, 26);
            this.textBox5.TabIndex = 16;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("楷体", 15F, System.Drawing.FontStyle.Bold);
            this.label13.Location = new System.Drawing.Point(3, 10);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(443, 20);
            this.label13.TabIndex = 107;
            this.label13.Text = "01:確認測試PORT板與電控箱連接線是否正常。";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("楷体", 15F, System.Drawing.FontStyle.Bold);
            this.label14.Location = new System.Drawing.Point(3, 46);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(348, 20);
            this.label14.TabIndex = 108;
            this.label14.Text = "02:壓力錶氣壓單位是否單位為kpa。";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("楷体", 15F, System.Drawing.FontStyle.Bold);
            this.label15.Location = new System.Drawing.Point(3, 82);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(441, 20);
            this.label15.TabIndex = 109;
            this.label15.Text = "03:確認PLC軟體版本為                  。";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("楷体", 15F, System.Drawing.FontStyle.Bold);
            this.label16.Location = new System.Drawing.Point(3, 154);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(480, 20);
            this.label16.TabIndex = 110;
            this.label16.Text = "04:確認O2計的讀值是否在範圍 20.3%~21.6% 間。";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("楷体", 15F, System.Drawing.FontStyle.Bold);
            this.label17.Location = new System.Drawing.Point(3, 190);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(480, 20);
            this.label17.TabIndex = 111;
            this.label17.Text = "05:確認O2計的讀值是否在範圍 20.3%~21.6% 間。";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("楷体", 15F, System.Drawing.FontStyle.Bold);
            this.label18.Location = new System.Drawing.Point(3, 226);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(531, 40);
            this.label18.TabIndex = 112;
            this.label18.Text = "06:確認按下EMS急停按鈕，\r\n   GUI端顯示欄位 “Status”需顯示紅色“NG”文字。";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("楷体", 15F, System.Drawing.FontStyle.Bold);
            this.label19.Location = new System.Drawing.Point(3, 282);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(547, 20);
            this.label19.TabIndex = 113;
            this.label19.Text = "07:QC完成後，貼上出廠流水號及檢驗標籤，並包裝裝妥。";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("楷体", 15F, System.Drawing.FontStyle.Bold);
            this.label20.Location = new System.Drawing.Point(3, 118);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(443, 20);
            this.label20.TabIndex = 114;
            this.label20.Text = "   確認GUI版本為                      。";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 769);
            this.Controls.Add(this.GET_MAC_button);
            this.Controls.Add(this.MAC_TO_PLCtextBox);
            this.Controls.Add(this.MAC_TO_HOST_textBox);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Machine_number_textBox);
            this.Controls.Add(this.Machine_number_label);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.Project_number_Save_button);
            this.Controls.Add(this.Port5_SN_textBox);
            this.Controls.Add(this.Port4_SN_textBox);
            this.Controls.Add(this.Port3_SN_textBox);
            this.Controls.Add(this.Port2_SN_textBox);
            this.Controls.Add(this.Master_SN_textBox);
            this.Controls.Add(this.Project_number_textBox);
            this.Controls.Add(this.Project_number_label);
            this.Controls.Add(this.Company_name);
            this.Controls.Add(this.Project_Name);
            this.Controls.Add(this.Member_of_Sintek_Group);
            this.Controls.Add(this.Logo);
            this.Controls.Add(this.Step_1);
            this.Controls.Add(this.SerialPort_comboBox);
            this.Controls.Add(this.Port5_checkBox);
            this.Controls.Add(this.Port4_checkBox);
            this.Controls.Add(this.Port3_checkBox);
            this.Controls.Add(this.Master_SN_label);
            this.Controls.Add(this.Port2_checkBox);
            this.Name = "Form1";
            this.Text = "PTLP_Checklist_V1.0";
            this.FontChanged += new System.EventHandler(this.Form1_FontChanged);
            ((System.ComponentModel.ISupportInitialize)(this.Logo)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.Visual_inspection.ResumeLayout(false);
            this.Visual_inspection.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.Power_safety_inspection.ResumeLayout(false);
            this.Power_safety_inspection.PerformLayout();
            this.Power_transmission_inspection.ResumeLayout(false);
            this.Power_transmission_inspection.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox SerialPort_comboBox;
        private System.Windows.Forms.Label Step_1;
        private System.Windows.Forms.PictureBox Logo;
        private System.Windows.Forms.Label Member_of_Sintek_Group;
        private System.Windows.Forms.Label Project_Name;
        private System.Windows.Forms.Label Company_name;
        private System.Windows.Forms.Label Project_number_label;
        private System.Windows.Forms.TextBox Project_number_textBox;
        private System.Windows.Forms.Label Master_SN_label;
        private System.Windows.Forms.TextBox Master_SN_textBox;
        private System.Windows.Forms.CheckBox Port2_checkBox;
        private System.Windows.Forms.CheckBox Port3_checkBox;
        private System.Windows.Forms.CheckBox Port4_checkBox;
        private System.Windows.Forms.CheckBox Port5_checkBox;
        private System.Windows.Forms.TextBox Port2_SN_textBox;
        private System.Windows.Forms.TextBox Port3_SN_textBox;
        private System.Windows.Forms.TextBox Port4_SN_textBox;
        private System.Windows.Forms.TextBox Port5_SN_textBox;
        private System.Windows.Forms.Button Project_number_Save_button;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage Visual_inspection;
        private System.Windows.Forms.TabPage Power_safety_inspection;
        private System.Windows.Forms.TabPage Power_transmission_inspection;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Q8_label;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label Machine_number_label;
        private System.Windows.Forms.TextBox Machine_number_textBox;
        private System.Windows.Forms.Label Q7_label;
        private System.Windows.Forms.Label Q6_label;
        private System.Windows.Forms.Label Q5_label;
        private System.Windows.Forms.Label Q4_label;
        private System.Windows.Forms.Label Q3_label;
        private System.Windows.Forms.Label Q2_label;
        private System.Windows.Forms.Label Q1_label;
        private System.Windows.Forms.TextBox Q8_O2_SN_textBox;
        private System.Windows.Forms.TextBox Q7_O2_SN_textBox;
        private System.Windows.Forms.TextBox Q8_O2_V_textBox;
        private System.Windows.Forms.TextBox Q7_O2_V_textBox;
        private System.Windows.Forms.TextBox Power_cord_length_textBox;
        private System.Windows.Forms.CheckBox Q6_Yes_CheckBox;
        private System.Windows.Forms.CheckBox Q6_NO_CheckBox;
        private System.Windows.Forms.TextBox Fuse_textBox;
        private System.Windows.Forms.TextBox NFB_textBox;
        private System.Windows.Forms.Label Q1_2_label;
        private System.Windows.Forms.Label Q1_1_label;
        private System.Windows.Forms.Label Q1_3_label;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox MAC_TO_HOST_textBox;
        private System.Windows.Forms.TextBox MAC_TO_PLCtextBox;
        private System.Windows.Forms.Button GET_MAC_button;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
    }
}

