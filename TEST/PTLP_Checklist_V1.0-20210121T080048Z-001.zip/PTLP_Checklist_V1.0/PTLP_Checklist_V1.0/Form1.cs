﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Management;
using System.IO;
using System.IO.Ports;
using System.Threading;
using System.Runtime.InteropServices;
using System.Net.NetworkInformation;

namespace PTLP_Checklist_V1._0
{
    public partial class Form1 : Form
    {
        static SerialPort _serialPort;
        bool _serialPort_IsOpen;
        string DataReceived_String;
        string str;
        int FocusIndex;
        public Form1()
        {
            InitializeComponent();
            //CheckForIllegalCrossThreadCalls = false;
            str = System.Environment.CurrentDirectory;
            IniManager iniManager = new IniManager(str + "\\Shipping_Date.ini");
            Project_number_textBox.Text = iniManager.ReadIniFile("Shipping_Date", "Project_number_textBox", "default");
            //Machine_number_textBox.Focus();
        }

        [DllImport("user32.dll", CharSet = CharSet.Auto, CallingConvention = CallingConvention.Winapi)]
        internal static extern IntPtr GetFocus();
            //获取 当前拥有焦点的控件
        private Control GetFocusedControl()
            {
                Control focusedControl = null;
                // To gethold of the focused control:
                IntPtr focusedHandle = GetFocus();
                if (focusedHandle != IntPtr.Zero)
                {
                    //focusedControl= Control.FromHandle(focusedHandle);
                    focusedControl = Control.FromChildHandle(focusedHandle);
                    FocusIndex = focusedControl.TabIndex;
                    label2.Text = focusedControl.TabIndex.ToString();
                }
                return focusedControl;
            }
        private void GetFocusIndex(object sender, EventArgs e)
        {
            GetFocusedControl();
        }
        public class IniManager
        {
            private string filePath;
            private StringBuilder lpReturnedString;
            private int bufferSize;

            [DllImport("kernel32")]
            private static extern long WritePrivateProfileString(string section, string key, string lpString, string lpFileName);

            [DllImport("kernel32")]
            private static extern int GetPrivateProfileString(string section, string key, string lpDefault, StringBuilder lpReturnedString, int nSize, string lpFileName);

            public IniManager(string iniPath)
            {
                filePath = iniPath;
                bufferSize = 512;
                lpReturnedString = new StringBuilder(bufferSize);
            }

            // read ini date depend on section and key
            public string ReadIniFile(string section, string key, string defaultValue)
            {
                //lpReturnedString ;
                GetPrivateProfileString(section, key, defaultValue, lpReturnedString, bufferSize, filePath);
                return lpReturnedString.ToString();
            }

            // write ini data depend on section and key
            public void WriteIniFile(string section, string key, Object value)
            {
                WritePrivateProfileString(section, key, value.ToString(), filePath);
            }
        }
        private void Project_number_Save(object sender, EventArgs e)
        {
            IniManager iniManager = new IniManager(str + "\\Shipping_Date.ini");

            iniManager.WriteIniFile("Shipping_Date", "Project_number_textBox", Project_number_textBox.Text);
        }
        private void SerialPort_comboBox_DropDown(object sender, EventArgs e)
        {
            SerialPort_comboBox.Items.Clear();
            string[] ports = SerialPort.GetPortNames();
            SerialPort_comboBox.Items.Add("Close");
            foreach (string port in ports)
            {
                SerialPort_comboBox.Items.Add(port);
            }
        }
        private void SerialPort_comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (SerialPort_comboBox.Text == string.Empty | SerialPort_comboBox.Text == "Close")
            {
                if (_serialPort_IsOpen)
                {
                    _serialPort.Close();
                    _serialPort_IsOpen = false;
                }
            }
            else
            {
                if (_serialPort_IsOpen)
                {
                    _serialPort.Close();
                    _serialPort_IsOpen = false;
                }
                try
                {
                    if (_serialPort_IsOpen == false)
                    {
                        _serialPort = new SerialPort(SerialPort_comboBox.Text);
                        //_serialPort.PortName = SerialPort_comboBox.Text;
                        _serialPort.BaudRate = 9600;
                        _serialPort.DataBits = 7;
                        _serialPort.Parity = Parity.Even;
                        _serialPort.StopBits = StopBits.One;
                        _serialPort.Open();
                        _serialPort.DataReceived += new SerialDataReceivedEventHandler(serialPort_DataReceived);
                        _serialPort_IsOpen = true;
                    }
                }
                catch (InvalidCastException ex)
                {
                    MessageBox.Show("Serial port opening failed");
                }

            }
        }
        private void SendMsg(bool port_Open, string str)
        {
            try
            {
                if (port_Open)
                {
                    _serialPort.Write(str);
                }
                else
                {
                    MessageBox.Show("Please open the serial port");
                }
            }
            catch (Exception)
            {
                //MessageBox.Show("Please open the serial port");
            }
        }
        private void serialPort_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            System.Threading.Thread.Sleep(100);
            string datastring = string.Empty;
            DataReceived_String = string.Empty;
            do
            {
                int count = _serialPort.BytesToRead;
                if (count <= 0)
                    break;
                byte[] readBuffer = new byte[count];

                Application.DoEvents();
                _serialPort.Read(readBuffer, 0, count);
                datastring += System.Text.Encoding.Default.GetString(readBuffer);

            } while (_serialPort.BytesToRead > 0);
            DataReceived_String = datastring.Substring(0, datastring.Length - 1);
            this.Invoke(new ChangeTextBoxEventHandler(ChangeTextBox1), DataReceived_String);
        }
        private void keyDown_E(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                GetFocusedControl();
                switch (FocusIndex)
                {
                    case 1:
                        Port2_SN_textBox.Focus();
                        Port2_SN_textBox.Text = string.Empty;
                        break;
                    case 2:
                        if (Port2_SN_textBox.Text == string.Empty)
                        {
                            Port2_checkBox.Checked = false;
                        }
                        else
                        {
                            Port2_checkBox.Checked = true;
                        }
                        Port3_SN_textBox.Focus();
                        Port3_SN_textBox.Text = string.Empty;
                        break;
                    case 3:
                        if (Port3_SN_textBox.Text == string.Empty)
                        {
                            Port3_checkBox.Checked = false;
                        }
                        else
                        {
                            Port3_checkBox.Checked = true;
                        }
                        Port4_SN_textBox.Focus();
                        Port4_SN_textBox.Text = string.Empty;
                        break;
                    case 4:
                        if (Port4_SN_textBox.Text == string.Empty)
                        {
                            Port4_checkBox.Checked = false;
                        }
                        else
                        {
                            Port4_checkBox.Checked = true;
                        }
                        Port5_SN_textBox.Focus();
                        Port5_SN_textBox.Text = string.Empty;
                        break;
                    case 5:
                        if (Port5_SN_textBox.Text == string.Empty)
                        {
                            Port5_checkBox.Checked = false;
                        }
                        else
                        {
                            Port5_checkBox.Checked = true;
                        }
                        NFB_textBox.Focus();
                        NFB_textBox.Text = string.Empty;
                        break;
                    case 6:
                        Fuse_textBox.Focus();
                        Fuse_textBox.Text = string.Empty;
                        break;
                    case 7:
                        Power_cord_length_textBox.Focus();
                        Power_cord_length_textBox.Text = string.Empty;
                        break;
                    case 8:
                        if (Power_cord_length_textBox.Text == string.Empty)
                        {
                            Q6_NO_CheckBox.Checked = true;
                            Q6_Yes_CheckBox.Checked = false;
                        }
                        else
                        {
                            Q6_NO_CheckBox.Checked = false;
                            Q6_Yes_CheckBox.Checked = true;
                        }
                        Q7_O2_V_textBox.Focus();
                        Q7_O2_V_textBox.Text = string.Empty;
                        break;
                    case 9:
                        Q7_O2_SN_textBox.Focus();
                        Q7_O2_SN_textBox.Text = string.Empty;
                        break;
                    case 10:
                        Q8_O2_V_textBox.Focus();
                        Q8_O2_V_textBox.Text = string.Empty;
                        break;
                    case 11:
                        Q8_O2_SN_textBox.Focus();
                        Q8_O2_SN_textBox.Text = string.Empty;
                        break;

                    default:
                        break;
                }
            }
        }

        void ChangeTextBox1(string DataReceived)
        {
            GetFocusedControl();
            switch (FocusIndex)
            {
                case 1:
                    Master_SN_textBox.Text = DataReceived_String;
                    Port2_SN_textBox.Focus();
                    break;
                case 2:
                    Port2_SN_textBox.Text = DataReceived_String;
                    Port2_checkBox.Checked = true;
                    Port3_SN_textBox.Focus();
                    break;
                case 3:
                    Port3_SN_textBox.Text = DataReceived_String;
                    Port3_checkBox.Checked = true;
                    Port4_SN_textBox.Focus();
                    break;
                case 4:
                    Port4_SN_textBox.Text = DataReceived_String;
                    Port4_checkBox.Checked = true;
                    Port5_SN_textBox.Focus();
                    break;
                case 5:
                    Port5_SN_textBox.Text = DataReceived_String;
                    Port5_checkBox.Checked = true;
                    NFB_textBox.Focus();
                    break;
                    
                case 9:
                    if (DataReceived.Length > 9)
                    { 
                        Q7_O2_V_textBox.Text = "V" + DataReceived.Substring(3,1) + "." + DataReceived.Substring(4, 2);
                    }
                    Q7_O2_SN_textBox.Text = DataReceived.Substring(6);
                    Q8_O2_SN_textBox.Focus();
                    break;
                case 10:
                    if (DataReceived.Length > 9)
                    {
                        Q7_O2_V_textBox.Text = "V" + DataReceived.Substring(3, 1) + "." + DataReceived.Substring(4, 2);
                    }
                    Q7_O2_SN_textBox.Text = DataReceived.Substring(6);
                    Q8_O2_SN_textBox.Focus();
                    break;
                case 11:
                    if (DataReceived.Length > 9)
                    {
                        Q8_O2_V_textBox.Text = "V" + DataReceived.Substring(3, 1) + "." + DataReceived.Substring(4, 2);
                    }
                    Q8_O2_SN_textBox.Text = DataReceived.Substring(6);
                    //Q8_O2_SN_textBox.Focus();
                    break;
                case 12:
                    if (DataReceived.Length > 9)
                    {
                        Q8_O2_V_textBox.Text = "V" + DataReceived.Substring(3, 1) + "." + DataReceived.Substring(4, 2);
                    }
                    Q8_O2_SN_textBox.Text = DataReceived.Substring(6);
                    //Q8_O2_SN_textBox.Focus();
                    break;
                    
                default:
                    
                    break;
            }
        }
        delegate void ChangeTextBoxEventHandler(string DataReceived);

        private void Port2_checkBox_CheckedChanged(object sender, EventArgs e)
        {
            if (Port2_checkBox.Checked == true)
            {
                if (Port2_SN_textBox.Text == string.Empty)
                {
                    Port2_checkBox.Checked = false;
                }
            }
            else
            {
                Port2_SN_textBox.Text = string.Empty;
            }

        }
        private void Port3_checkBox_CheckedChanged(object sender, EventArgs e)
        {
            if (Port3_checkBox.Checked == true)
            {
                if (Port3_SN_textBox.Text == string.Empty)
                {
                    Port3_checkBox.Checked = false;
                }
            }
            else
            {
                Port3_SN_textBox.Text = string.Empty;
            }
        }
        private void Port4_checkBox_CheckedChanged(object sender, EventArgs e)
        {
            if (Port4_checkBox.Checked == true)
            {
                if (Port4_SN_textBox.Text == string.Empty)
                {
                    Port4_checkBox.Checked = false;
                }
            }
            else
            {
                Port4_SN_textBox.Text = string.Empty;
            }
        }
        private void Port5_checkBox_CheckedChanged(object sender, EventArgs e)
        {
            if (Port5_checkBox.Checked == true)
            {
                if (Port5_SN_textBox.Text == string.Empty)
                {
                    Port5_checkBox.Checked = false;
                }
            }
            else
            {
                Port5_SN_textBox.Text = string.Empty;
            }
        }
        private void Q6_NO_CheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (Power_cord_length_textBox.Text == string.Empty)
            {
                Q6_NO_CheckBox.Checked = true;
                Q6_Yes_CheckBox.Checked = false;
            }
            else
            {
                if (Q6_NO_CheckBox.Checked == true)
                {
                    Power_cord_length_textBox.Text = string.Empty;
                    Q6_Yes_CheckBox.Checked = false;
                }
            }
        }
        private void Q6_Yes_CheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (Power_cord_length_textBox.Text == string.Empty)
            {
                Q6_NO_CheckBox.Checked = true;
                Q6_Yes_CheckBox.Checked = false;
            }
            else
            {
                if (Q6_Yes_CheckBox.Checked == false)
                {
                    Power_cord_length_textBox.Text = string.Empty;
                    Q6_NO_CheckBox.Checked = true;
                }
            }
        }

        private void Project_number_textBox_Click(object sender, EventArgs e)
        {
            GetFocusedControl();
            Project_number_textBox.Text = string.Empty;
            SendMsg(_serialPort_IsOpen, "LON\r");
        }
        private void Master_SN_textBox_Click(object sender, EventArgs e)
        {
            GetFocusedControl();
            Master_SN_textBox.Text = string.Empty;
            SendMsg(_serialPort_IsOpen, "LON\r");
        }
        private void Port2_SN_textBox_Click(object sender, EventArgs e)
        {
            GetFocusedControl();
            Port2_checkBox.Checked = false;
            Port2_SN_textBox.Text = string.Empty;
            SendMsg(_serialPort_IsOpen, "LON\r");
        }
        private void Port3_SN_textBox_Click(object sender, EventArgs e)
        {
            GetFocusedControl();
            Port3_checkBox.Checked = false;
            Port3_SN_textBox.Text = string.Empty;
            SendMsg(_serialPort_IsOpen, "LON\r");
        }
        private void Port4_SN_textBox_Click(object sender, EventArgs e)
        {
            GetFocusedControl();
            Port4_checkBox.Checked = false;
            Port4_SN_textBox.Text = string.Empty;
            SendMsg(_serialPort_IsOpen, "LON\r");
        }
        private void Port5_SN_textBox_Click(object sender, EventArgs e)
        {
            GetFocusedControl();
            Port5_checkBox.Checked = false;
            Port5_SN_textBox.Text = string.Empty;
            SendMsg(_serialPort_IsOpen, "LON\r");
        }
        private void Q7_O2_Click(object sender, EventArgs e)
        {
            GetFocusedControl();
            Q7_O2_SN_textBox.Text = string.Empty;
            Q7_O2_V_textBox.Text = string.Empty;
            SendMsg(_serialPort_IsOpen, "LON\r");
        }
        private void Q8_O2_Click(object sender, EventArgs e)
        {
            GetFocusedControl();
            Q8_O2_SN_textBox.Text = string.Empty;
            Q8_O2_V_textBox.Text = string.Empty;
            SendMsg(_serialPort_IsOpen, "LON\r");
        }

        private void Form1_FontChanged(object sender, EventArgs e)
        {
            label1.Text = "123";
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Port2_SN_textBox.Focus();
        }

        private void GET_MAC_button_Click(object sender, EventArgs e)
        {
            int i = 0;
            try
            {
                NetworkInterface[] interfaces = NetworkInterface.GetAllNetworkInterfaces();
                foreach (NetworkInterface ni in interfaces)
                {
                    if (interfaces[i].Name == "Ethernet")
                        MAC_TO_HOST_textBox.Text = BitConverter.ToString(ni.GetPhysicalAddress().GetAddressBytes());
                    if (interfaces[i].Name == "Ethernet 2")
                        MAC_TO_PLCtextBox.Text = BitConverter.ToString(ni.GetPhysicalAddress().GetAddressBytes());
                    i++;
                }
            }
            catch (Exception)
            {
            }
        }
    }
}
